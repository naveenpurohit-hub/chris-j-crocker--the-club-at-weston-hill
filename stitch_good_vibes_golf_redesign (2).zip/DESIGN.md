---
name: Vibrant Sports-Tech
colors:
  surface: '#121415'
  surface-dim: '#121415'
  surface-bright: '#38393a'
  surface-container-lowest: '#0c0e0f'
  surface-container-low: '#1a1c1d'
  surface-container: '#1e2021'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333536'
  on-surface: '#e2e2e3'
  on-surface-variant: '#c4c9ac'
  inverse-surface: '#e2e2e3'
  inverse-on-surface: '#2f3132'
  outline: '#8e9379'
  outline-variant: '#444933'
  surface-tint: '#abd600'
  primary: '#ffffff'
  on-primary: '#283500'
  primary-container: '#c3f400'
  on-primary-container: '#556d00'
  inverse-primary: '#506600'
  secondary: '#c5c7c8'
  on-secondary: '#2e3132'
  secondary-container: '#444748'
  on-secondary-container: '#b3b5b6'
  tertiary: '#ffffff'
  on-tertiary: '#442b00'
  tertiary-container: '#ffddb1'
  on-tertiary-container: '#895b00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c3f400'
  primary-fixed-dim: '#abd600'
  on-primary-fixed: '#161e00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#e1e3e4'
  secondary-fixed-dim: '#c5c7c8'
  on-secondary-fixed: '#191c1d'
  on-secondary-fixed-variant: '#444748'
  tertiary-fixed: '#ffddb1'
  tertiary-fixed-dim: '#fdba51'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#121415'
  on-background: '#e2e2e3'
  surface-variant: '#333536'
  electric-lime: '#CCFF00'
  obsidian-deep: '#0D0F10'
  charcoal-surface: '#1A1D1E'
  vibe-gold: '#EDAC44'
  glass-border: rgba(255, 255, 255, 0.12)
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
  stat-value:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  gutter: 16px
  section-gap: 64px
---

## Brand & Style

This design system embodies the "Vibrant Sports-Tech" aesthetic, bridging the gap between high-precision golf simulation and a high-energy social atmosphere. The brand personality is premium yet approachable, sophisticated yet electric. It targets a modern demographic of golfers who value both data-driven performance and a vibrant social experience.

The visual style is defined by a **Glassmorphic** approach layered over a deep, obsidian-inspired foundation. The interface utilizes translucent surfaces, subtle background blurs, and vibrant "Electric Lime" accents that mimic the glow of premium simulator turf. The overall feel is immersive, mimicking the high-tech interior of a modern indoor golf lounge. High-quality photography of social interactions and technical golf swings should be integrated as primary visual anchors behind semi-transparent UI layers.

## Colors

The palette is anchored by **Obsidian Deep**, a near-black neutral that provides a sophisticated backdrop for technical data. The primary accent is **Electric Lime**, a high-chroma green used to signal action, highlight performance metrics, and represent the "Good Vibes" energy. 

**Charcoal Surface** is used for card backgrounds and elevated containers, while **Vibe Gold** (carried over from the original brand assets) is reserved for premium callouts, loyalty rewards, or "Pro" level features. The color strategy relies on high contrast between the dark background and the luminous primary accents to ensure readability in low-light social environments.

## Typography

Typography balances technical precision with modern editorial flair. **Manrope** is used for headlines and statistics, providing a geometric yet warm character. Its bold weights are essential for creating the "impactful" headlines requested.

**Inter** handles body copy and functional UI elements, ensuring maximum legibility across all device types. For technical data—such as club speed, launch angle, and spin rates—**JetBrains Mono** is introduced as a label font to evoke a "pro-data" and technical feel. All display text should favor tight letter-spacing for a more aggressive, modern look, while body text maintains standard spacing for comfort.

## Layout & Spacing

This design system utilizes a **fluid grid** model with fixed maximum widths for desktop environments (1440px). The layout rhythm is based on an 8px square grid, ensuring consistent vertical and horizontal alignment.

- **Desktop:** 12-column grid with 24px gutters and 80px side margins.
- **Tablet:** 8-column grid with 16px gutters and 40px side margins.
- **Mobile:** 4-column grid with 16px gutters and 20px side margins.

Margins and paddings should be generous to maintain the premium feel. Grouped technical stats should use tighter spacing (8px or 12px), while social content and photography-heavy sections should use expansive gaps (48px to 64px) to let the visuals breathe.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Glassmorphism**. Rather than traditional heavy shadows, depth is communicated by the translucency of surfaces.

1.  **Base Layer:** Solid Obsidian Deep (#0D0F10).
2.  **Surface Layer:** Semi-transparent Charcoal (rgba(26, 29, 30, 0.8)) with a 12px backdrop blur.
3.  **Floating Elements:** Elements like buttons or active cards feature a subtle "inner glow" (a 1px top border of 20% opacity white) to simulate light catching the edge of glass.
4.  **Accents:** Subtle radial gradients in Electric Lime with low opacity (10-15%) can be used behind key cards to create a "glowing turf" effect, drawing the eye to primary calls to action.

## Shapes

The shape language uses a **medium roundedness (8px)** to strike a balance between the sharp, technical world of golf data and the friendly, inviting nature of a social club. 

- **Small Components:** Checkboxes and small tags use a 4px radius.
- **Standard Components:** Buttons, input fields, and standard cards use the 8px base radius.
- **Large Containers:** Modals and large feature sections use a 16px or 24px radius to feel more approachable and modern.

## Components

- **Buttons:** Primary buttons are solid Electric Lime with black text for maximum "pop." Secondary buttons use the glass style (blurred background, 1px white border) with white text.
- **Chips & Tags:** Small, pill-shaped markers for categories like "League Play" or "New Session." Use JetBrains Mono for the text within these tags.
- **Input Fields:** Dark, recessed backgrounds with a subtle 1px border. On focus, the border glows Electric Lime with a soft outer shadow.
- **Cards:** The core of the UI. Cards utilize the glassmorphic style. Technical data cards should be clean and grid-based, while social/event cards should use full-bleed photography as the background with text overlays.
- **Progress Indicators:** Use thin, neon-style lines in Electric Lime. For score tracking or "vibe levels," use glowing gradients.
- **Lists:** Clean, separated by low-opacity white lines (10% opacity). Each list item should have a hover state that slightly increases the background's translucency.